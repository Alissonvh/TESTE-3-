# Projeto Storm - Fullstack

Este projeto contém o frontend e backend do Projeto Storm, estruturado para deploy na Vercel.

## Estrutura do Projeto

- `/frontend` - Aplicação React com Vite
- `/backend` - API Node.js com Express

## Correções Realizadas

- Corrigido o conflito de dependências entre `date-fns` e `react-day-picker`
- Adicionado arquivo `vercel.json` para configurar o build na Vercel
- Estruturado como monorepo para facilitar o desenvolvimento e deploy

## Como Fazer o Deploy

### GitHub

1. Crie um repositório no GitHub
2. Faça o upload deste projeto para o repositório
3. Certifique-se de que todos os arquivos estejam incluídos, especialmente o `vercel.json`

### Vercel

1. Acesse a [Vercel](https://vercel.com)
2. Importe o projeto do GitHub
3. A Vercel detectará automaticamente as configurações do projeto
4. Clique em "Deploy" para iniciar o processo

## Desenvolvimento Local

Para executar o projeto localmente:

```bash
# Instalar dependências
npm install

# Executar em modo de desenvolvimento
npm run dev

# Construir para produção
npm run build
```
