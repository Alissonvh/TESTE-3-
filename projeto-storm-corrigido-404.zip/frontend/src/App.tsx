import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// Páginas públicas
import LandingPage from './pages/LandingPage';
import ComoFunciona from './pages/ComoFunciona';
import Planos from './pages/Planos';
import Login from './pages/Login';
import Cadastro from './pages/Cadastro';

// Páginas internas
import Painel from './pages/Painel';

// Componente de rota protegida
const RotaProtegida = ({ children }: { children: JSX.Element }) => {
  const token = localStorage.getItem('token');
  
  if (!token) {
    return <Navigate to="/entrar" replace />;
  }
  
  return children;
};

function App() {
  const [, setIsAuthenticated] = useState(!!localStorage.getItem('token'));

  return (
    <Router>
      <Routes>
        {/* Rotas públicas */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/como-funciona" element={<ComoFunciona />} />
        <Route path="/planos" element={<Planos />} />
        <Route path="/entrar" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
        <Route path="/cadastro" element={<Cadastro setIsAuthenticated={setIsAuthenticated} />} />
        
        {/* Rotas protegidas */}
        <Route 
          path="/painel" 
          element={
            <RotaProtegida>
              <Painel />
            </RotaProtegida>
          } 
        />
        <Route 
          path="/materias" 
          element={
            <RotaProtegida>
              <Painel />
            </RotaProtegida>
          } 
        />
        <Route 
          path="/anotacoes" 
          element={
            <RotaProtegida>
              <Painel />
            </RotaProtegida>
          } 
        />
        <Route 
          path="/flashcards" 
          element={
            <RotaProtegida>
              <Painel />
            </RotaProtegida>
          } 
        />
        <Route 
          path="/revisar" 
          element={
            <RotaProtegida>
              <Painel />
            </RotaProtegida>
          } 
        />
        <Route 
          path="/configuracoes" 
          element={
            <RotaProtegida>
              <Painel />
            </RotaProtegida>
          } 
        />
        
        {/* Rota para qualquer caminho não definido */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
