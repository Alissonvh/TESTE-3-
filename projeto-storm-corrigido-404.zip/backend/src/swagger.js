const swaggerAutogen = require('swagger-autogen')();

const doc = {
  info: {
    title: 'Secure TypeScript REST API',
    description: 'API documentation for Secure TypeScript REST API',
    version: '1.0.0',
  },
  host: process.env.API_URL || 'localhost:3000',
  basePath: '/api',
  schemes: ['http', 'https'],
  securityDefinitions: {
    bearerAuth: {
      type: 'apiKey',
      in: 'header',
      name: 'Authorization',
      description: 'Enter your bearer token in the format **Bearer {token}**',
    },
  },
  components: {
    schemas: {
      RegisterRequest: {
        type: 'object',
        properties: {
          name: { type: 'string', example: 'John Doe' },
          email: { type: 'string', example: 'john@example.com' },
          password: { type: 'string', example: 'password123' },
        },
      },
      LoginRequest: {
        type: 'object',
        properties: {
          email: { type: 'string', example: 'john@example.com' },
          password: { type: 'string', example: 'password123' },
        },
      },
      LoginResponse: {
        type: 'object',
        properties: {
          success: { type: 'boolean', example: true },
          data: {
            type: 'object',
            properties: {
              user: {
                type: 'object',
                properties: {
                  id: { type: 'string', example: '123e4567-e89b-12d3-a456-426614174000' },
                  name: { type: 'string', example: 'John Doe' },
                  email: { type: 'string', example: 'john@example.com' },
                  createdAt: { type: 'string', example: '2023-01-01T00:00:00.000Z' },
                  updatedAt: { type: 'string', example: '2023-01-01T00:00:00.000Z' },
                },
              },
              accessToken: { type: 'string', example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' },
              refreshToken: { type: 'string', example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' },
            },
          },
          message: { type: 'string', example: 'Login successful' },
        },
      },
      RefreshResponse: {
        type: 'object',
        properties: {
          success: { type: 'boolean', example: true },
          data: {
            type: 'object',
            properties: {
              accessToken: { type: 'string', example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' },
              refreshToken: { type: 'string', example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' },
            },
          },
          message: { type: 'string', example: 'Token refreshed successfully' },
        },
      },
      UserResponse: {
        type: 'object',
        properties: {
          success: { type: 'boolean', example: true },
          data: {
            type: 'object',
            properties: {
              id: { type: 'string', example: '123e4567-e89b-12d3-a456-426614174000' },
              name: { type: 'string', example: 'John Doe' },
              email: { type: 'string', example: 'john@example.com' },
              createdAt: { type: 'string', example: '2023-01-01T00:00:00.000Z' },
              updatedAt: { type: 'string', example: '2023-01-01T00:00:00.000Z' },
            },
          },
          message: { type: 'string', example: 'User retrieved successfully' },
        },
      },
      UpdateUserRequest: {
        type: 'object',
        properties: {
          name: { type: 'string', example: 'John Doe' },
          email: { type: 'string', example: 'john@example.com' },
          password: { type: 'string', example: 'password123' },
        },
      },
    },
  },
};

const outputFile = './src/swagger.json';
const endpointsFiles = ['./src/routes/index.ts'];

// Generate swagger.json
swaggerAutogen(outputFile, endpointsFiles, doc);