# Secure TypeScript REST API

A secure TypeScript REST API with Express.js, Prisma ORM, PostgreSQL, JWT authentication, and Zod schema validation.

## Features

- 🔒 Secure JWT authentication with refresh token mechanism
- 🔄 Clean architecture with separation of concerns
- 📝 Data validation using Zod schema
- 📊 Multi-tenant architecture preparation
- 📄 API documentation with Swagger/OpenAPI
- 🚀 Deployment configuration for Railway/Render

## Tech Stack

- **Language**: TypeScript
- **Framework**: Express.js
- **ORM**: Prisma
- **Database**: PostgreSQL
- **Authentication**: JWT with refresh token mechanism
- **Data validation**: Zod schema validation

## Project Structure

```
src/
├── controllers/      # Request handlers
├── services/         # Business logic
├── middlewares/      # Express middlewares
├── routes/           # API routes
├── schemas/          # Zod validation schemas
├── types/            # TypeScript type definitions
├── utils/            # Utility functions
├── config/           # Configuration files
├── index.ts          # Application entry point
└── swagger.js        # Swagger configuration
```

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- PostgreSQL database

### Installation

1. Clone the repository

```bash
git clone https://github.com/yourusername/secure-typescript-api.git
cd secure-typescript-api
```

2. Install dependencies

```bash
npm install
```

3. Set up environment variables by creating a `.env` file based on `.env.example`

```
DATABASE_URL="postgresql://user:password@localhost:5432/mydb?schema=public"
JWT_SECRET="your-jwt-secret-key"
JWT_REFRESH_SECRET="your-jwt-refresh-secret-key"
JWT_EXPIRES_IN="15m"
REFRESH_TOKEN_EXPIRES_IN="7d"
PORT=3000
NODE_ENV="development"
```

4. Create and migrate the database

```bash
npm run prisma:generate
npm run prisma:migrate
```

5. Start the development server

```bash
npm run dev
```

## API Documentation

API documentation is available at `/api-docs` when the server is running.

### API Endpoints

#### Authentication

- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login a user
- `POST /api/auth/refresh` - Refresh access token
- `POST /api/auth/logout` - Logout a user

#### User

- `GET /api/users/me` - Get current user profile
- `PUT /api/users/me` - Update user profile

## Error Handling

The API uses consistent error responses with the following format:

```json
{
  "success": false,
  "message": "Error message",
  "code": 400,
  "errors": [
    {
      "code": "invalid_type",
      "expected": "string",
      "received": "undefined",
      "path": ["email"],
      "message": "Email is required"
    }
  ]
}
```

## Deployment

### Railway

1. Create a new project in Railway
2. Connect your GitHub repository
3. Add PostgreSQL plugin
4. Set environment variables
5. Deploy

### Render

1. Create a new Web Service in Render
2. Connect your GitHub repository
3. Set build command: `npm install && npm run build`
4. Set start command: `npm start`
5. Add environment variables
6. Deploy

## License

MIT